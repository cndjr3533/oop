'''
파일의 열기 모드
r : 읽기 모드, 파일이 없으면 실패,
w : 쓰기 모드, 파일의 유무와 관계가 없음, 항상 새파일
a : 추가 모드, 쓰기모드이면서 파일이 있어야 가능하고, 내용이 기존 내용뒤에 추가됨
=============
b : binary mode
t : text mode
'''

# file = open('C:\\Users\\User\\Documents\\test.txt', 'r')

# with open('C:\\test.txt', 'w', encoding='utf-8') as file:
#     file.write('안녕하세요\n')
#     file.write('파이썬으로 만든 파일입니다')

# with open('test.csv', 'w', encoding='utf-8') as csv_file:
#     csv_file.write('1,2,3\n')
#     csv_file.write('4,5,6\n')
#     csv_file.write('7,8,9\n')

with open('C:\\test.txt', 'r', encoding='utf-8') as file:
    while True:
        lines = file.readline()
        if not lines:
            break

        print(lines)

print('\n\n')


with open('C:\\test.txt', 'r', encoding='utf-8') as file:
    lines = file.readlines()
    print(lines)


with open('C:\\test.txt', 'r', encoding='utf-8') as file:
    # lines = ''
    while True:
        buf = file.read(4)
        if not buf:
            break
        print(buf, end='')

