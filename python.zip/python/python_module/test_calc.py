# import calculator as calc   # as를 이용하여 별칭 지정
from calculator import add, subtract as sub
from calculator import div
import filecopy

import time
import random
import math

# print(calculator.add(1,2))
# print(calculator.subtract(3,2))

# 별칭으로 모듈을 불러왔을때
# print(calc.add(1,2))
# print(calc.subtract(3,2))

# add(3, 5)
# subtract(5,1)

if __name__=='__main__':
    sub(3,1)

