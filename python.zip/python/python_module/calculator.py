def add(num1, num2):
    return num1+num2

def subtract(num1, num2):
    return num1-num2

def multiply(num1, num2):
    return num1*num2

def div(num1, num2):
    return num1 // num2

def mod(num1, num2):
    return num1 % num2


if __name__ == '__main__':
    # 테스트 코드를 여기에...
    print(mod(10,3))
