'''

<img src="https://flexible.img.hani.co.kr/flexible/normal/640/469/imgdb/original/2024/0505/20240505500600.jpg"/>


'''
import json


def make_tag(news:dict) -> str:
    return f'''
        <div>
            <div>
                <img style="width:100px; height:100px;" src="{news["urlToImage"]}">
            </div>
            
            <div>
                <a href="{news["url"]}"> {news["title"]} </a>
                <p> {news["description"]} </p>
            </div>
        </div>
    '''





with open('news.json', 'r', encoding='utf-8') as json_file:
    text = json_file.read()
    # print(text)
    news_data = json.loads(text)    # 파싱(Parsing)해서 딕셔너리 또는 리스트 형태로 변환
    # print(news_data['status'])  
      
    # print(news_data['articles'][0]['title'])
    li = []
    for news in news_data['articles']:
        li.append( make_tag(news) )

    with open('test.html', 'w', encoding='utf-8') as html:
        for tag in li:
            html.write(tag)

