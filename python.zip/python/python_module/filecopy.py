'''
이것은 모듈의 doc-string 입니다.

'''




def copy_file(src_file:str, target_file:str, buf_size:int=1024)->None:
    ''' doc-string
    copy_file 함수 : 이 함수는 원본 파일명을 받아서 target_file명으로 주어진
    대상 파일로 복사하는 함수입니다. 

    매개변수)
    src_file : 원본 파일명, 문자열
    target_file : 대상 파일명, 문자열
    buf_size : 읽기,쓰기 복사의 메모리 버퍼 크기, 정수형

    반환값 : 없음
    '''
    with open(src_file, 'rb') as src_file:  # 원본 파일 오픈
        with open(target_file, 'wb') as target_file:
            while True:
                # src_file로부터 1024바이트 읽어서, buf에 저장
                buf = src_file.read(buf_size)                
                if not buf: # buf에 읽어들인 내용이 없으면                
                    break   # while 문을 탈출한다
                target_file.write(buf)


# 매개 변수로 원본파일명과 타겟 파일명을 전달하면
# 타겟 파일을 생성하여 원본 파일을 복사하는 함수를 만드세요



# copy_file('source.zip', 'copy.zip')
# copy_file('source.zip', 'copy.zip', 4096)
# copy_file('source.zip', 'copy.zip', 512)

# print(False)        # False
# print(bool(0))      # False
# print(bool(''))     #
# print(bool([]))     # 



def find_data(number:list, to_find:int|str)->int:
    index = 0
    for i in number:
        if i==to_find:
            return index
        
        index += 1
    return -1

li = [1,2,3]
#num = 123
find_data(li, 4)


def add(num1:int, num2:int)->int:
    return num1 + num2

num = add(1,2)
num = add(1.1, 2.5)
num = add('1','2')  # 이런 문자열 연산은 허용하지 않겠다(의지)
print(num)
num = add()



