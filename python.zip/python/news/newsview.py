import os  #운영체제의 명령들을  처리할 수 있는 모듈
import json #json 데이터를 처리하기 위함
import requests  


class NewsConfig:  #클래스 명만 시작할때 대문자로 시작
    '''news api를 처리하기 위한 config.json 파일을 읽어서 처리하는 클래스'''
    def __init__(self, config_file:str) -> None: #매개변수로 config파일을 받는다. 생성자의 반환값은 객체 그자체. 읽다가 실패하면 예외처리(raise)를 한다.
        #가급적이면 if는 안하는 방향으로 만들어라
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)   #제이슨 모듈이 파일을 다 읽는다. 딕셔너리 형태로 config에 넣는다
                self.__base_url = config['base_url']  #외부에서 안보이게 __ 처리를한것.
                self.__api_key = config['api_key']
                self.__category = config['category']
                self.__language = config['language']
        except Exception as e:  #Exception 은 최상위 예외 class이다. 에러를 예외로 예외처리하려고 설정
            print(f'Error : {e}')
            raise Exception(f'Error : {e}')
        
    def __repr__(self) -> str :
        return f'NewsConfig : {self.__base_url},{self.__api_key},{self.__category},{self.__language}'
    
    def get_language(self) -> iter :  #반복가능한 객체의 최상위 는 iter
        return self.__language
    
    def get_lang_code(self, i:int) -> str :
        return self.__language[i]['code'].lower()  #랭귀지 딕셔너리에 i ㅈ번째 코드 가져오는것 .lower 소문자강제
    
    def get_categories(self) -> iter:
        return self.__category
    
    def get_category(self, i:int) -> str:
        return self.__category[i].lower()
    
    def get_api_key(self) -> str:
        return self.__api_key
    
    def get_base_url(self) -> str:
        return self.__base_url
    
    
class NewsLoader: #실제로 일하는놈
    '''News API 사이트로부터 뉴스 기사를 로드하고 정보를 제공 '''
    def __init__(self) -> None:
        self.status = 'not yet'
        self.total_results = 0
        self.articles = []
        self.pages = 0
        self.vpp = 20  #페이지 보이는게 한번에 20 밖에 안되기떄문에 20 설정
    
    
    
    def remove_quotes(self) -> None: #
        # di = {'title':} #이렇게 되어있으면 s1 은 None이다 s1=None 
        # s1 = di['title']
        # s1 = s1.replace('"','') #문자열의 함수, 문자열이어야만 호출이 되는것 근데 None,아무것도 없기때문에 raise가 실행되고 에러문구가 나온다
        # s1 = s1.replaece('"','') if s1 is not None else '' #삼항연산자를 이용해서 s1에 데이터가 없다면 공백을 출력.
        for article in self.articles: #아티클스안에 들어와있는 모든 데이터들에 대해서
            article['title'] = article['title'].replace('"','') if article['title'] is not None else '' # replace 는 첫번째 매개변수를 두번째 매개변수로 바꿔준다. 바뀐문자열을 반환해주는것. 자기자신을 변경하는게 아니기때문에 반환하는것을 다시 받아야한다 그래서 해당 형태가 된다
            article['description'] = article['description'].replace('"','') if article['description'] is not None else ''
            article['author'] = article['author'].replace('"','') if article['author'] is not None else ''
            
        
    def load_news_from_url(self, url:str) -> None:
        try:
            print(url)
            response = requests.get(url)
            news_json = response.json() #response 객체로부터 json 데이터를 추출한다
            if news_json['status'] != 'ok':
                raise Exception('Error : Unable to load news')
            
            self.articles += news_json['articles'] #시퀀스 연산자. 덮어쓰기가아닌 옆으로 채우려면 이런식으로 작성
            self.status = news_json['status']
            self.total_results = int(news_json['totalResults'])
            self.remove_quotes()
            
            
        except Exception as e:
            print(f'error: {e}')
            raise Exception(f'error: {e}')
    
    def load_news(self, base_url:str, api_key:str, lang:str, category:str, vpp:int=20):    
        try:
            url = f'{base_url}?counry={lang}&apiKey={api_key}'
            if category.lower() != 'topic' : #url이 topic이 아니면 아래 문구를 url에 추가한다.
                url += f'&category={category}' #카테고리는 우리가 topic 을만들어놨다 없을수 있기때무에 따로 작업해야한다 
                
            self.load_news_from_url(url) #한페이지를 가져온것. 기사 20개
            self.vpp = vpp
            
            self.__calculate_total_pages()
            for i in range(2, self.pages+1): #시작값, 끝값-1 까지 가져오기때문에 +1한것
                page_url = url + f'&page={i}' #페이지수를 넣는 작업
                self.load_news_from_url(page_url)
            
            
            
        except Exception() as e:
            print(f'Error : {e}')
            raise Exception(f'Error : {e}')
        
    def __calculate_total_pages(self) -> None: #함수옆에 None은 반환값이 없다는뜻
        if self.vpp == 0:
            return
        
        
        page = self.total_results // self.vpp
        nam = self.total_results % self.vpp
        self.pages == page if nam == 0 else page +1 #페이지수를 결정하는데 나머지 값이 0이면 그냥 결과값주고 0이 아니면 페이지수에 +1  #self.pages = self.total_results // self.vpp + 1 # 페이지 수 설정 토탈 리절트 결과값에 vpp 설정한것으로 나눠서 페이지수 설정 
        
        
        
    def get_total_results(self) ->int:
        return self.total_results


def clear_screen():
    os.system('cls' if os.name=='nt' else 'clear')  # 3항 연산자 윈도우가 nt 윈도우면 cls 전달 아니면 clear 전달

if __name__ == '__main__':
    news_conf = NewsConfig('config.json')
    print(news_conf)
    
    clear_screen() #화면을 청소한다
    
    
    for i, lang in enumerate(news_conf.get_language()):  #인덱스하고 같이 가져올수 있게 해주겠다
        print(f'{i+1} : {lang["code"]}, {lang["name"]}')
        
    sel = int(input('나라를 선택하세요 >>> '))
    lang_code = news_conf.get_lang_code(sel-1) #표시 컴퓨터에서는 0에서부터 가져가기때문에 -1 해둔다
    
    
    
    print()
        
    for i, cate in enumerate(news_conf.get_categories()):
        print(f'{i+1} : {cate}')
        
    sel = int(input('카테고리를 선택하세요 >>>'))
    category = news_conf.get_category(sel-1)
    
    clear_screen()
    
    news_loader = NewsLoader()
    news_loader.load_news(news_conf.get_base_url(),
                          news_conf.get_api_key(),
                          lang_code,
                          category)
    
    
    
    print(f'Total Results : {news_loader.get_total_results()}')
    print()
    print(f'cout of articles : {len(news_loader.articles)}')
    print()
    
    for i, article in enumerate(news_loader.articles):
        print('------------------------------------------')
        print(f'No : {i+1}')
        print(f'Title : {article["title"]}')
        print(f'Description : {article["description"]}')
        print(f'URL : {article["url"]}')
        print(f'Image URL : {article["urlToImage"]}')
        print(f'Author : {article["author"]}')
        print(f'PublishedAt : {article["publishedAt"]}')
        print(f'Source : {article["source"]["name"]}')
        
    
     