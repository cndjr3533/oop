from person import Person

# Student 클래스는 Person클래스로부터 상속되어 구현
class Student(Person):
    '''
    Student 클래스는 Person 클래스의 자식 클래스로 정의
    Student 클래스는 Person 클래스로부터 파생된다
    Person 클래스는 Student 클래스의 부모(super class) 클래스
    Student 클래스는 Person 클래스의 subclass 이다
    '''
    def __init__(self, shcool, age=0, name='이름없음') -> None:
        '''
        생성자 재정의
        '''
        super().__init__(age, name)     
        print()   
        self.__school = shcool  # private : 외부와 상속받은 클래스에서 접근할 수 없다, 
        self.grade = 1          # public : 접근 제한이 없다
        # self._number          # protected : 외부에서 접근금지, 상속 가능

    def __repr__(self) -> str:

        # self.__name : private 멤버는 상속되나 사용할 수 없음
        name = self.get_name()  
        age = self.get_age()
        return f'나는 {name}이고, {age}살 입니다, 학교는 {self.__school} 입니다'
        


lee1 = Student('안양학교', 10, 'lee')
lee2 = Student('안양학교', 10, 'lee')

lee1.__name = '이동국'      # private 멤버에 접근
lee2.__age = 20            # private 멤버에 접근

## reprsent를 재정의하여 아래와 같은 출력 결과를 만드세요
'나는 xx이고, xx살 입니다, 학교는 xx 입니다'
print(lee1)
print(lee2)

