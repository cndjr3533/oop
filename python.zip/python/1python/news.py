Class News:
    def __init__(self) -> None:
        pass
    
    
    news = News()
    