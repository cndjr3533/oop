class Person:
  def __init__(self, age=0, name='이름없음')->None:
    '''Person 클래스의 생성자'''    
    self.__age = age
    self.__name = name

  def set_name(self, age, name)->None:
    self.__age = age
    self.__name = name

  def get_age(self):
    return self.__age
  
  def get_name(self):
    return self.__name

  def introduce(self)->None:
    print(f'저의 이름은 {self.__name}이고 나이는 {self.__age} 입니다')

  def __repr__(self) -> str:
    return f'{self.__age}, {self.__name}'

  def __eq__(self, o: object) -> bool:
    if not isinstance(o, Person):   # o객체가 Person class가 아니면
      return False                  # False(거짓)을 반환한다
    
    return self.__age==o.__age and self.__name==o.__name
  
  # eq, ne, lt, le, gt, ge
  def __lt__(self, o: object) -> bool:
    if not isinstance(o, Person):   # o객체가 Person class가 아니면
      return False                  # False(거짓)을 반환한다
    
    return self.__age < o.__age
    
    
if __name__ == '__main__':
  # class : 객체를 정의하는 코드, (설계도)
  # 객체(object) : 클래스로부터 생성된 구현체(추상적임)
  # 인스턴스(instance) : 메모리에서 실행중인 객체
  kim = Person()      # Person Class로부터 kim이라는 객체 생성
  kim2 = Person()     # Person Class로부터 kim2이라는 객체 생성
  kim.set_name(20, 'Kim')
  kim2.set_name(20, 'Kim')
  print(kim)


  # if kim==num2:

  if kim == kim2:
    print('kim과 kim2는 서로 같습니다')
  else:
    print('kim과 kim2는 다릅니다')

  if kim < kim2:
    print('kim은 kim2보다 작습니다')
  else:
    print('kim은 kim2보다 작지 않습니다')


  # print( isinstance(kim, Person) )
  # print( isinstance(kim, list))

  # kim.introduce()
  # print(kim)

  # kim.age = 10      # 객체 내부의 데이터를 바꿈
  # kim.name = 'kim'  # 객체 내부의 데이터를 바꿈

  # li = list([1,2,3,4,5])
  # print(li)